//
//  ViewController.swift
//  RemoteConfigureDemo
//
//  Created by NineSol Tech on 07/12/2023.
//

import UIKit
import FirebaseRemoteConfig
import GoogleMobileAds
import Firebase

class ViewController: UIViewController {
    
    @IBOutlet weak var iconImage: UIImageView!
    @IBOutlet weak var txtLbl: UILabel!
    @IBOutlet weak var view2: UIView!
    @IBOutlet weak var view1: UIView!
    
    
    private let remoteConfig = RemoteConfig.remoteConfig()
    
    private var rewardedInterstitialAd: GADRewardedInterstitialAd?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fetchValue()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        addloadrewardedInterstitialAd()
    }
    
    
   func addloadrewardedInterstitialAd() {
        GADRewardedInterstitialAd.load(withAdUnitID:"ca-app-pub-3940256099942544/6978759866",
                                       request: GADRequest()) { ad, error in
            if let error = error {
                return print("Failed to load rewarded interstitial ad with error: \(error.localizedDescription)")
            }
            
            self.rewardedInterstitialAd = ad
            self.rewardedInterstitialAd?.fullScreenContentDelegate = self
        }

    }
    
    @IBAction func buttonAction(_ sender: UIButton) {
        show()
    }
    
    
    func show() {
      guard let rewardedInterstitialAd = rewardedInterstitialAd else {
        return print("Ad wasn't ready.")
      }

      rewardedInterstitialAd.present(fromRootViewController: self) {
        let reward = rewardedInterstitialAd.adReward
        // TODO: Reward the user!
      }
    }
    
    //MARK: -  Firebase Remote Congiguration
    func fetchValue() {
        let settings = RemoteConfigSettings()
        settings.minimumFetchInterval = 0
        remoteConfig.configSettings = settings
        
        self.remoteConfig.fetch(withExpirationDuration: 0) { status, error in
            if status == .success, error == nil {
                self.remoteConfig.activate(completion: { _, _ in
                    let remoteConfigDemo = self.remoteConfig.configValue(forKey: "RemoteConfigureDemo").jsonValue as? [String: Any] ?? [:]
                    
                    let iconValue = remoteConfigDemo["icon"] as? [String: Any]
                    let iconStatus = iconValue?["Value"] as? Int ?? 0
                    print("Icon Value Fetch: \(iconStatus)")
                    DispatchQueue.main.async {
                        self.UpdateAdsViaFirebase(status: iconStatus)
                    }
                    
                    let viewValue = remoteConfigDemo["uiview1"] as? [String: Any]
                    let viewStatus = viewValue?["Value"] as? Int ?? 0
                    print("uiview Value Fetch: \(viewStatus)")
                    DispatchQueue.main.async {
                        self.viewUpdateAdsViaFirebase(status: viewStatus)
                    }
                })
            } else {
                print("Something went wrong")
            }
        }
    }
    
    func UpdateAdsViaFirebase(status: Int) {
        if status == 1 {
            iconImage.image = UIImage(named: "8")
        } else {
            iconImage.image = UIImage(named: "7")
        }
    }
    
    func viewUpdateAdsViaFirebase(status: Int) {
        if status == 1 {
            view1.isHidden = true
        } else {
            view1.isHidden = false
        }
    }
    
    
}

extension ViewController: GADFullScreenContentDelegate {

  /// Tells the delegate that the ad failed to present full screen content.
  func ad(_ ad: GADFullScreenPresentingAd, didFailToPresentFullScreenContentWithError error: Error) {
    print("Ad did fail to present full screen content.")
  }

  /// Tells the delegate that the ad will present full screen content.
  func adWillPresentFullScreenContent(_ ad: GADFullScreenPresentingAd) {
    print("Ad will present full screen content.")
  }

  /// Tells the delegate that the ad dismissed full screen content.
  func adDidDismissFullScreenContent(_ ad: GADFullScreenPresentingAd) {
    print("Ad did dismiss full screen content.")
  }
}

//
//func checkIfNameExistsInFirebase(node: String, name: String, completion: @escaping (Bool) -> Void) {
//    let clickCountRef = Database.database().reference().child(node).child(name)
//
//    clickCountRef.observeSingleEvent(of: .value) { snapshot in
//        completion(snapshot.exists())
//    }
//}
//
//func increaseCounterInFirebase(node: String, name: String) {
//    let clickCountRef = Database.database().reference().child(node).child(name)
//
//    clickCountRef.runTransactionBlock { (currentData: MutableData) -> TransactionResult in
//        if var count = currentData.value as? Int {
//            count += 1
//            currentData.value = count
//        } else {
//            currentData.value = 1
//        }
//        return TransactionResult.success(withValue: currentData)
//    }
//}
//
//
//func setCounterInFirebase(node: String, name: String, count: Int) {
//    let clickCountRef = Database.database().reference().child(node).child(name)
//    clickCountRef.setValue(count)
//}
//
//func updateCounterInFirebase(for selectedItem: DataModel, node: String) {
//    let itemName = selectedItem.name
//
//    checkIfNameExistsInFirebase(node: node, name: itemName) { exists in
//        if exists {
//            self.increaseCounterInFirebase(node: node, name: itemName)
//        } else {
//            self.setCounterInFirebase(node: node, name: itemName, count: 1)
//        }
//    }
//}

// Usage for stylesArray
//let selectedStyleItem = stylesArray[indexPath.item]
//updateCounterInFirebase(for: selectedStyleItem, node: "style")
